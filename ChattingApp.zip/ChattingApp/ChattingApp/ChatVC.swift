//
//  ChatVC.swift
//  ChattingApp
//
//  Created by WjdanMo on 07/12/2021.
//

import UIKit
import Firebase

class ChatVC: UIViewController {
    
    
    @IBOutlet weak var tableView: UITableView!
    
    @IBOutlet weak var textField: UITextField!
    
    let firestore = Firestore.firestore()
    
    var messages = [Message]()
    var name = ""
    var id = ""
    var myId = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        tableView.delegate = self
        tableView.dataSource = self
        tableView.reloadData()
        loadMessages()
    }
    
    
    @IBAction func sendMessage(_ sender: Any) {
        
        sendMsg()
        
    }
    
    func sendMsg(){
        myId = Auth.auth().currentUser!.uid
        let messageData = ["Sender": myId ,
                           "Content" : textField.text!,
                           "Date": Date().timeIntervalSince1970] as [String : Any]
        
        
        firestore.collection("Messages").addDocument(data: messageData) { error in
            if let error = error{
                print("erorrrr", error)
            }
            else{
                print("added")
            }
        }
        self.tableView.reloadData()
        
    }
    
    func loadMessages(){
        
        firestore.collection("Messages").order(by: "Date").addSnapshotListener{ querySnapshot, error in
            
            self.messages = []
            
            if let error = error {
                print("error")
            }
            else{
                if let snapshotDocs = querySnapshot?.documents{
                    for doc in snapshotDocs{
                        let data = doc.data()
                        if let messageSender = data["Sender"] as? String , let messageContent = data["Content"] as? String {
                            let newMessage = Message(sender: messageSender, content: messageContent)
                            self.messages.append(newMessage)
                            
                            DispatchQueue.main.async {
                                self.tableView.reloadData()
                            }
                        }
                    }
                }
            }
        }
    }
}


extension ChatVC: UITableViewDelegate, UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return messages.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "MessageCell") as! MessageCell
        
        cell.sender.text = messages[indexPath.row].sender
        cell.content.text = messages[indexPath.row].content
        
        return cell
    }
}


struct Message {
    var sender : String
    var content : String
}


