//
//  HomeVC.swift
//  ChattingApp
//
//  Created by WjdanMo on 07/12/2021.
//

import UIKit
import Firebase

class HomeVC: UIViewController {

    @IBOutlet weak var tableView: UITableView!
    
    let firestore = Firestore.firestore()
    
    var usersArray = [Users]()
    
    var sentName : String?
    var sentId : String?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.delegate = self
        tableView.dataSource = self
        getFBUsers()
                
    }
    
   
    @IBAction func signoutbtn(_ sender: Any) {
        do {
            try Auth.auth().signOut()
            self.dismiss(animated: true, completion: nil)
        }
        catch {
            print(error.localizedDescription)
        }
    }
    
    func getFBUsers (){
        firestore.collection("Users").getDocuments { snapShot, error in
            for user in snapShot!.documents{
                print(user.documentID)
                self.usersArray.append(Users(name: user.get("Name") as! String , id: user.get("ID") as! String))
            }
            self.tableView.reloadData()
        }
    }
}

extension HomeVC: UITableViewDelegate, UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return usersArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "UserCell") as! UserCell
        
        cell.lable.text = usersArray[indexPath.row].name
        return cell
    }
    
    
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        sentName = usersArray[indexPath.row].name
        sentId = usersArray[indexPath.row].id
        
        self.performSegue(withIdentifier: "segue", sender:self)
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if segue.identifier == "segue" {
            let vc = segue.destination as! ChatVC
            vc.name = sentName!
            vc.id = sentId!
            
        }
    }
}

struct Users{
    var name : String
    var id : String
    
}
