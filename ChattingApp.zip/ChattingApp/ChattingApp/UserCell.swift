//
//  UserCell.swift
//  ChattingApp
//
//  Created by WjdanMo on 07/12/2021.
//

import UIKit

class UserCell: UITableViewCell {

  
    
    @IBOutlet weak var lable: UILabel!
    
    @IBOutlet weak var userImage: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
