//
//  ViewController.swift
//  ChattingApp
//
//  Created by WjdanMo on 07/12/2021.
//

import UIKit
import Firebase

class ViewController: UIViewController {

    let firestore = Firestore.firestore()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func signin(_ sender: Any) {

        if Auth.auth().currentUser?.uid == nil {
            
            Auth.auth().signInAnonymously { user , error in
                if error == nil {
                    let userData = ["Name": "user1" ,
                                    "ID": user?.user.uid]
                    self.firestore.collection("Users").document((user?.user.uid)!).setData(userData as [String : Any])
                    
                    self.performSegue(withIdentifier: "segue", sender: self)
                }
            }
        }
        else{
            self.performSegue(withIdentifier: "segue", sender: self)
        }
    }
}

